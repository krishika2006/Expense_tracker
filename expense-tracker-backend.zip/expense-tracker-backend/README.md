# Expense Tracker Backend

Node.js + Express + MongoDB REST API for an expense tracker frontend.

## Requirements
- Node.js 18+
- MongoDB running locally, or a MongoDB Atlas connection string

## Setup (Windows / VS Code)
1. Extract this folder.
2. Open the `expense-tracker-backend` folder in VS Code.
3. In the terminal run:
   ```bash
   npm install
   ```
4. Copy `.env.example` to a new file named `.env`.
5. Set `MONGODB_URI` to your MongoDB connection string and replace `JWT_SECRET` with a long random secret.
6. Start the API:
   ```bash
   npm run dev
   ```
7. Open `http://localhost:5000/api/health`. You should see an API running message.

## API endpoints
All protected endpoints require header:
`Authorization: Bearer YOUR_TOKEN`

### Authentication
- `POST /api/auth/register` JSON: `{ "name": "Mahesh", "email": "you@example.com", "password": "secret123" }`
- `POST /api/auth/login` JSON: `{ "email": "you@example.com", "password": "secret123" }`
- `GET /api/auth/me`

### Transactions
- `GET /api/expenses`
- `GET /api/expenses/summary`
- `POST /api/expenses` JSON: `{ "title": "Groceries", "amount": 500, "category": "Food", "type": "expense", "date": "2026-10-26", "note": "" }`
- `PUT /api/expenses/:id` (same fields as POST)
- `DELETE /api/expenses/:id`
- Optional list filters: `?type=expense`, `?category=Food`, `?from=2026-01-01&to=2026-12-31`

`type` can be `expense` or `income`. Each user's transactions are isolated by the authenticated user ID.

## Frontend connection
Set the frontend API base URL to `http://localhost:5000/api`. Send the JWT token returned by register/login as `Authorization: Bearer <token>` for `/expenses` requests. Your existing frontend may use different field names; adjust its API calls to match these endpoints.
